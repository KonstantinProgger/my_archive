# Snake

# Icons

Icons icon.ico and snake.png from <a target="_blank" href="https://icons8.ru">Icons8</a>

# Music

Fluffing a Duck by Kevin MacLeod

Link: https://incompetech.filmmusic.io/song/3766-fluffing-a-duck

License: http://creativecommons.org/licenses/by/4.0/
